# bolt-nativescript-js-ijfqet

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/tejas69-art/bolt-nativescript-js-ijfqet)